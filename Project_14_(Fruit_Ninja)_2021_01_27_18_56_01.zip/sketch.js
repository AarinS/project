var sword,alien;
var swordImage,alienImage,gameOverImage;
var fruitGroup, enemyGroup;
var PLAY = 1;
var END = 0;
var gameState = 1;

function preload(){
  swordImage = loadImage("sword.png");
  fruit1 = loadImage("fruit1.png");
  fruit2 = loadImage("fruit2.png");
  fruit3 = loadImage("fruit3.png");
  fruit4 = loadImage("fruit4.png");
  alienImage = loadImage("alien1.png");
  gameOverImage = loadImage("gameover.png");
}

function setup() {
  createCanvas(400, 400);
  //creating sword
  sword = createSprite(40,200,20,20);
  sword.addImage(swordImage);
  sword.scale = 0.7;
  
  sword.setCollider("rectangle",0,0,40,40);
  
  score = 0;
  fruitGroup = new Group();
  enemyGroup = new Group();
  
    
  
   
}

function draw() {
  background("black")
 
  

if(gameState === PLAY){
if(fruitGroup.isTouching(sword)){
  fruitGroup.destroyEach();
  score=score+2;
}
if(enemyGroup.isTouching(sword)){
  sword.addImage(gameOverImage);
  sword.x = 200;
  sword.y = 200;
  gameState = END;
}
 fruits();
 Enemy();

sword.y=World.mouseY;
sword.x=World.mouseX;
}


 

if(gameState === END) {
  fruitGroup.destroyEach();
  enemyGroup.destroyEach();
fruitGroup.setVelocityXEach(0);
  enemyGroup.setVelocityXEach(0);
}  
 text("Score: "+ score,350,25);
 drawSprites(); 
}  
function fruits() {
  if(World.frameCount % 80 === 0){
    fruit = createSprite(400,200,20,20);
    fruit.scale=0.2;
    r=Math.round(random(1,4));
    if(r == 1) {
      fruit.addImage(fruit1);
    } else if(r == 2) {
      fruit.addImage(fruit2)
    } else if (r == 3) {
      fruit.addImage(fruit3);
    } else {
      fruit.addImage(fruit4);
}
    fruit.y=Math.round(random(50,340));
    
    fruit.velocityX = -7;
    fruit.setLifetime=100;
    fruitGroup.add(fruit);
}
}
function Enemy(){
  if(World.frameCount % 200 === 0){
    alien = createSprite(400,200,20,20);
    alien.addAnimation("moving",alienImage);
    alien.y = Math.round(random(100,300));
    alien.velocityX = -7;
    alien.setLifetime = 100;
    enemyGroup.add(alien);
    
}
}



